<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Cyber Security Resource Center</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> 
        <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" crossorigin="anonymous">
        <!-- Fonts -->   
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800" rel="stylesheet">    
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  
    </head>
    <body>
            <div id="main" class="main_section">
            <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
            <?php echo $__env->yieldContent('content'); ?>
            </div>


    </body>
</html>